<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-10-29 13:57:43 --> 404 Page Not Found --> http://cms:8888/dummy
