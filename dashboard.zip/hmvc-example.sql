-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2016 at 09:50 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hmvc-example`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `disc` varchar(100) DEFAULT NULL,
  `pubdate` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `disc`, `pubdate`) VALUES
(3, 'HOUSE KEEPING ', 'LOREAM IPSUM DUMMY CONTENT', '2016-07-07'),
(4, 'HOME CLEANING', 'loraem ipsum dummy  ', '2016-07-08'),
(6, 'wdsfjgv', 'erfdfveqwrf', '2016-07-08'),
(7, 'wqefre3ft', 'wqefrewf', '2016-07-08'),
(8, 'sdfgdsdfgd', 'asdfgdsfdgdf', '2016-07-08'),
(9, 'wergwerg', 'gewrgreg', '2016-07-08'),
(10, 'ergewrg', 'ergerwg', '2016-07-08'),
(11, 'ergewrgewrger', 'ergewrgewr', '2016-07-08'),
(12, 'gergreger', 'gerwgertg', '2016-07-08'),
(13, 'erwgewrgtre', 'ewrgrewgetrgyer', '2016-07-08'),
(14, 'BIKE SERVICING', 'xyz', '2016-07-09');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
`id` int(11) NOT NULL,
  `task_type` enum('in-person','online') NOT NULL DEFAULT 'online',
  `task_location` varchar(100) NOT NULL,
  `task_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
`id` int(11) unsigned NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `body` text,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `order`, `body`, `parent_id`, `registered_date`) VALUES
(3, 'Home', 'home', NULL, 'xyz', 0, '2016-07-04 02:20:11'),
(4, 'Test3', 'Products', NULL, '<p>hello</p>', 3, '2016-07-04 03:13:49'),
(5, 'Test2', 'Products4', NULL, 'fergr', 0, '2016-07-04 02:21:32');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
`id` int(11) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `pubdate` date NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `pubdate`, `body`, `created`, `modified`) VALUES
(1, 'xyz', 'fdgfd', '2016-07-11', '<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li>\r\n	<h2 style="font-style:italic"><strong>dfgbfbhgbn</strong></h2>\r\n	</li>\r\n</ol>\r\n\r\n<p><img alt="" src="http://www.gettyimages.pt/gi-resources/images/Homepage/Hero/PT/PT_hero_42_153645159.jpg" style="float:right" /></p>\r\n\r\n<table border="1" cellpadding="1" cellspacing="1" style="width:500px">\r\n	<tbody>\r\n		<tr>\r\n			<td>Title</td>\r\n			<td>Body</td>\r\n		</tr>\r\n		<tr>\r\n			<td>hello</td>\r\n			<td>test</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>', '2016-07-11 04:51:43', '2016-07-11 05:48:55');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
`id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(0, 'user'),
(1, 'admin'),
(2, 'editor');

-- --------------------------------------------------------

--
-- Table structure for table `task_details`
--

CREATE TABLE IF NOT EXISTS `task_details` (
`id` int(11) unsigned NOT NULL,
  `task_title` varchar(100) NOT NULL,
  `task_disc` varchar(400) NOT NULL,
  `task_status` enum('draft','pending','active','completed','assigned') NOT NULL DEFAULT 'draft',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task_details`
--

INSERT INTO `task_details` (`id`, `task_title`, `task_disc`, `task_status`, `created`, `modified`, `user_id`) VALUES
(1, 'Home service', 'clean-my-house-efdvcefr', 'draft', '2016-07-08 00:00:00', '2016-07-09 09:51:03', 1),
(2, 'OFFICE CLEANING', 'DBCASDJ-VC-HELLO', 'draft', '2016-07-08 00:00:00', '2016-07-09 10:16:53', 1),
(4, 'OFFICE CLEANING', 'DBCASDJ-VC', 'draft', '2016-07-08 00:00:00', '2016-07-09 09:55:45', 1),
(6, 'HBUIIP0O', 'e3d34rfer4', 'draft', '2016-07-09 10:07:31', '2016-07-09 10:32:25', 1),
(7, 'xyz Task', 'fevrfg', 'draft', '2016-07-09 10:07:42', '2016-07-09 10:16:27', 1),
(8, 'wefddwe', '8R6F8UY7FTROI8', 'draft', '2016-07-09 10:32:16', '2016-07-09 10:32:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) unsigned NOT NULL,
  `user_login` varchar(60) DEFAULT NULL,
  `user_pass` varchar(1000) DEFAULT NULL,
  `user_nicename` varchar(64) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `activation_key` varchar(64) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `activation_key`, `created`, `modified`, `status`) VALUES
(8, 'admin', 'CC3A34E75D5F08A550BDEA92F525382B7D9ACE3FB8FAD29088CCDCE6EC99D255BAA4AFE1BDCC1605D3F1735F80CC69AAA8226FD64299F81882E6215008A5B8C7', 'vivek', 'kumarvivek865@gmail.com', '1', '2016-07-01 10:20:29', NULL, 12),
(11, 'hello', 'cc3a34e75d5f08a550bdea92f525382b7d9ace3fb8fad29088ccdce6ec99d255baa4afe1bdcc1605d3f1735f80cc69aaa8226fd64299f81882e6215008a5b8c7', 'vivek 34', 'deme1@gmail.com', NULL, '2016-07-04 04:59:45', NULL, NULL),
(12, '', 'cc3a34e75d5f08a550bdea92f525382b7d9ace3fb8fad29088ccdce6ec99d255baa4afe1bdcc1605d3f1735f80cc69aaa8226fd64299f81882e6215008a5b8c7', 'jsbodner81', 'kumarvivek865@gmailD.com', '', '2016-07-09 10:35:59', '2016-07-09 10:35:59', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_roles`
--

CREATE TABLE IF NOT EXISTS `users_roles` (
  `user_id` int(11) unsigned NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
 ADD PRIMARY KEY (`id`), ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
 ADD PRIMARY KEY (`id`), ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task_details`
--
ALTER TABLE `task_details`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_roles`
--
ALTER TABLE `users_roles`
 ADD PRIMARY KEY (`user_id`,`role_id`), ADD KEY `fk_users_roles_roles1_idx` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `task_details`
--
ALTER TABLE `task_details`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_roles`
--
ALTER TABLE `users_roles`
ADD CONSTRAINT `fk_users_roles_roles1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
ADD CONSTRAINT `fk_users_roles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
