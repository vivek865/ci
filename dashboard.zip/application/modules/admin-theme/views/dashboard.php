<?php $this->load->view('includes/head'); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <!-- Main Header -->
  <header class="main-header">

    <!-- Logo -->
    <a href="<?php echo base_url() ; ?>admin" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Admin</b>LTE</span>
    </a>
<?php $this->load->view('includes/menu'); ?>
</header>
<aside class="main-sidebar">
<?php $this->load->view('includes/sidebar'); ?>
</aside>
<div class="content-wrapper">
<?php $this->load->view('includes/bredcumb'); ?>
    <!-- Main content -->
    <section class="content">

     <?php $this->load->view($main_content); ?> 
	 

    </section>


</div>
<?php $this->load->view('includes/footer'); ?>
