<?php
class Task extends Admin_Controller
{

	public function __construct ()
	{
		parent::__construct();
		$this->load->model('task_m');
	}

	public function index ()
	{
		// Fetch all task
		$this->data['task'] = $this->task_m->get();
		
		// Load view
		 $this->data['main_content'] = 'list-task';
	  $this->load->view('admin-theme/dashboard',$this->data );
	}

	public function edit ($id = NULL)
	{
		// Fetch a task or set a new one
		if ($id) {
			$this->data['task'] = $this->task_m->get($id);
			count($this->data['task']) || $this->data['errors'][] = 'task could not be found';
		}
		else {
			$this->data['task'] = $this->task_m->get_new();
		}
		
		// Set up the form
		$rules = $this->task_m->rules;
		$this->form_validation->set_rules($rules);
		
		// Process the form
		if ($this->form_validation->run() == TRUE) {
			$data = $this->task_m->array_from_post(array(
				'task_title',
				'task_disc', 
			));
			$this->task_m->save($data, $id);
			redirect('admin/task');
		}
		
		// Load the view
		$this->data['main_content'] = 'edit-task';
		$this->load->view('admin-theme/dashboard', $this->data);
	}

	public function delete ($id)
	{
		$this->task_m->delete($id);
		redirect('admin/task');
	}
	
	
}