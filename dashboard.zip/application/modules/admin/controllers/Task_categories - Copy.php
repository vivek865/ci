<?php
class Task_categories extends Admin_Controller
{

	public function __construct ()
	{
		parent::__construct();
		$this->load->model('task_cat_m');
	}

	public function index ()
	{
		// Fetch all cat
		$this->data['cat'] = $this->cat_m->get();
		
		// Load view
		 $this->data['main_content'] = 'list-cat';
	  $this->load->view('admin-theme/dashboard',$this->data );
	}

	public function edit ($id = NULL)
	{
		// Fetch a cat or set a new one
		if ($id) {
			$this->data['cat'] = $this->cat_m->get($id);
			count($this->data['cat']) || $this->data['errors'][] = 'cat could not be found';
		}
		else {
			$this->data['cat'] = $this->cat_m->get_new();
		}
		
		// Set up the form
		$rules = $this->cat_m->rules;
		$this->form_validation->set_rules($rules);
		
		// Process the form
		if ($this->form_validation->run() == TRUE) {
			$data = $this->cat_m->array_from_post(array(
				'title', 
				'disc', 
				'pubdate'
			));
			$this->cat_m->save($data, $id);
			redirect('admin/cat');
		}
		
		// Load the view
		$this->data['main_content'] = 'edit-cat';
		$this->load->view('admin-theme/dashboard', $this->data);
	}

	public function delete ($id)
	{
		$this->cat_m->delete($id);
		redirect('admin/cat');
	}
	

}