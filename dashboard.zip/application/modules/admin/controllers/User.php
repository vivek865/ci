<?php
//User controller 
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends Admin_Controller {
	
	
	function __Construct ()
	{
		parent :: __construct() ;
		$this->load->library('Admin_Controller');
	}
	
	//load user list view in admin panel
	function index()
	{ 
	    //fetching user details  from the database 
	    $this->data['users']  =  $this->user_m->user_list() ;
		$this->data['main_content'] = 'list-users';
		//calling the user view and sending the fetched data to user list view  
		$this->load->view('admin-theme/dashboard' ,$this->data);
	}
	
	//Adding New User Rrecords 
		 public function add_user() 
		{ 
		//Running form validation
			$rules = $this->user_m->rules_admin;
			$this->form_validation->set_rules($rules);
			if ($this->form_validation->run() == TRUE) {
				//loading post data through array 
				$data = $this->user_m->array_from_post(array('user_nicename', 'user_email', 'user_pass'));
				//Encrypting Password to Sha512 with encryption key 
				$data['user_pass'] = $this->user_m->hash($data['user_pass']);
				// Saving user data to Table
				$this->user_m->save($data, $id=NULL);
				//redirect('admin/user');
			  }
			  //calling Add-user form
		    $this->data['main_content'] = 'add-user';
		    $this->load->view('admin-theme/dashboard',$this->data );
		}
		
		//callback function for checking wether mail is unique or not 
			public function _unique_email ($str)
			{
				//Assigning id from the url to $id variable 
				$id = $this->uri->segment(4);
				//retreving user email information from the User Table
				$this->db->where('user_email', $this->input->post('user_email'));
				!$id || $this->db->where('id !=', $id);
				$user = $this->user_m->get();
				//checking wether  eamil addresss existing or not and return the value true or false 
				if (count($user)) {

					$this->form_validation->set_message('_unique_email', '%s should be unique');
					return FALSE;
				}
				
				return TRUE;
			}
	
	//edit and update user 
		public function edit_user ($id = NULL)
		{
			//conditional statement to check wether (create new user or edit the existing user  through the id if id is present then condional stat              go for edit else  create the new user )
			if ($id) {
				$this->data['user'] = $this->user_m->get($id);
				count($this->data['user']) || $this->data['errors'][] = 'User could not be found';
			}
			else {
				$this->data['user'] = $this->user_m->get_new();
			}
			// Form Validation for the form
			$rules = $this->user_m->rules_admin;
			$id || $rules['user_pass']['rules'] .= '|required';
			$this->form_validation->set_rules($rules);
			if ($this->form_validation->run() == TRUE) {
				//retreving post data from the edit form 
				$data = $this->user_m->array_from_post(array('user_nicename','user_login', 'user_email', 'user_pass'));
				//converting the password to SHA512 with encription key 
				$data['user_pass'] = $this->user_m->hash($data['user_pass']);
				// Saving the  data to the User Table
				$this->user_m->save($data, $id);
				redirect('admin/user');
			}
			
			$this->data['main_content'] = 'edit-user';
			//loading the user view with updated user data
			$this->load->view('admin-theme/dashboard', $this->data);
		}
	
	    //delete user from records 
		 public function delete_user() 
		{ 
			$this->user_m->delete_user() ;
			redirect('admin/user');
		}
}