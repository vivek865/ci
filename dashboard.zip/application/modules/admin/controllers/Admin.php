<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends Admin_Controller {
	
	function __construct ()
	{
	parent::__construct();
	$this->load->library('Admin_Controller');
	}
	 // index function
		 public function index() 
		{
		  $this->data['main_content'] = 'includes/content';
		  $this->load->view('admin-theme/dashboard',$this->data );
		}
	//user Rgistration
		public function register()
		{
			$dashboard = 'admin';
			$this->user_m->loggedin() == FALSE || redirect($dashboard);
			
			$rules1 = $this->user_m->rules1;
			$this->form_validation->set_rules($rules1);
			if ($this->form_validation->run() == TRUE) {
				// We can register  and redirect
				if ( $this->user_m->register() == TRUE) {
					redirect($dashboard);
				}
				else {
					$this->session->set_flashdata('register', 'registration not  sucesfully');
					redirect('admin/register', 'refresh');
				} 
			}
			$this->data['main_content'] = 'register';
			$this->load->view('admin-theme/blank-layout', $this->data);
			
			
		}
		// user login validation
			public function login()
			{
				$dashboard = 'admin';
				$this->user_m->loggedin() == FALSE || redirect($dashboard);
				$rules = $this->user_m->rules;
				$this->form_validation->set_rules($rules);
				if ($this->form_validation->run() == TRUE) {
					// We can login and redirect
					if ($this->user_m->login() == TRUE) {
						redirect($dashboard);
					}
					else {
						$this->session->set_flashdata('error', 'That email/password combination does not exist');
						redirect('admin/login', 'refresh');
					}
				}
				$this->data['main_content'] = 'login';
				$this->load->view('admin-theme/blank-layout', $this->data);
			}
			//loggout function
			public function logout(){
				$this->user_m->logout();
				redirect('admin/login');
			}
	
	}
	
	
