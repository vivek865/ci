<?php $this->load->view('includes/header'); ?>
<?php $this->load->view('includes/menu'); ?>
<?php $this->load->view('includes/sidebar'); ?>
<?php $this->load->view('includes/content'); ?>
<?php $this->load->view('includes/footer'); ?>
