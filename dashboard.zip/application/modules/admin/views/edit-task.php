<div class=" col-md-offset-2 col-md-8 "><div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo empty($task->id) ? 'Add a new task ' : 'Edit task ' . $task->task_title; ?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
            
    <div class="text-center">    <?php echo validation_errors(); ?> </div>
<?php echo form_open(); ?>
              <div class="box-body form-horizontal">
               
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Title</label>

                  <div class="col-sm-10">
                    <?php echo form_input('task_title', set_value('task_title', $task->task_title), 'id="txtPlaces"','class="form-control"'); ?>
                  </div>
                </div>
                   <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">Discription</label>

                  <div class="col-sm-10">
                   <?php echo form_textarea('task_disc', set_value('task_disc', $task->task_disc),  'class="form-control"'); ?>
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
               <?php echo form_submit('submit', 'Save', 'class="btn btn-info pull-right"'); ?>
               
              </div>
              <!-- /.box-footer -->
     <?php echo form_close(); ?>
          </div>
		   <script>
$(function() {
	$('.datepicker').datepicker({ format : 'yyyy-mm-dd' });
});
</script>
 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?&sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('txtPlaces'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.lat();
                var longitude = place.geometry.location.lng();
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
                alert(mesg);
            });
        });
    </script>