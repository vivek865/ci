<div class=" col-md-offset-2 col-md-8 "><div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"> Update user</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
            
    <div class="text-center">    <?php echo validation_errors(); ?> </div>
<?php echo form_open(); ?>
              <div class="box-body form-horizontal">
               <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Name</label>

                  <div class="col-sm-10">
                    <input type="name"  name="user_nicename" class="form-control" value="<?php echo $user->user_nicename ;?> " id="inputEmail3" placeholder="Name">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">User</label>

                  <div class="col-sm-10">
                    <input type="name"  name="user_login" class="form-control" value="<?php echo $user->user_login ;?>"  id="inputEmail3" placeholder="Username">
                  </div>
                </div>
               
               
             
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Email</label>

                  <div class="col-sm-10">
                    <input type="email" class="form-control" name="user_email" value="<?php echo $user->user_email ;?>"  id="inputEmail3" placeholder="Email">
                  </div>
                </div>
                
                   <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">PassWord</label>

                  <div class="col-sm-10">
                    <input type="password" class="form-control" name="user_pass" id="inputEmail3" placeholder="Password">
                  </div>
                </div>
                   <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">Confirm Password</label>

                  <div class="col-sm-10">
                    <input type="password" class="form-control" name="password_confirm" id="inputEmail3" placeholder="CONFIRM PASSWORD">
                  </div>
                </div>
                
               
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
              
                <button type="submit" class="btn btn-info pull-right">Update user </button>
              </div>
              <!-- /.box-footer -->
     <?php echo form_close(); ?>
          </div>