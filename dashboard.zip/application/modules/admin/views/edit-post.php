<div class=" col-md-offset-1 col-md-10 "><div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo empty($post->id) ? 'Add a new post' : 'Edit post ' . $post->title; ?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
            
    <div class="text-center">    <?php echo validation_errors(); ?> </div>
<?php echo form_open(); ?>
              <div class="box-body form-horizontal">
               <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Publication date</label>

                  <div class="col-sm-10">
                   <?php echo form_input('pubdate', set_value('pubdate', $post->pubdate), 'class="datepicker form-control"'); ?>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Title</label>

                  <div class="col-sm-10">
                    <?php echo form_input('title', set_value('title', $post->title), 'class="form-control"'); ?>
                  </div>
                </div>
               
               
             
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Slug</label>

                  <div class="col-sm-10">
                   <?php echo form_input('slug', set_value('slug', $post->slug), 'class="form-control"'); ?>
                  </div>
                </div>
                
                   <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">Body</label>

                  <div class="col-sm-10">
                   <?php echo form_textarea('body', html_entity_decode(set_value('body', $post->body)), 'id="editor1"', 'class="form-control"'); ?>
                  </div>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
               <?php echo form_submit('submit', 'Save', 'class="btn btn-info pull-right"'); ?>
               
              </div>
              <!-- /.box-footer -->
     <?php echo form_close(); ?>
          </div>
		   <script>
$(function() {
	$('.datepicker').datepicker({ format : 'yyyy-mm-dd' });
});
</script>