<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Task List </h3> <h3 class="box-title" style=" float:right ; margin-right: 50% "> <?php echo anchor('admin/task/edit', '<i class="fa fa-plus-circle"></i> Add Task'); ?></h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body ">
            <table id="example1" class="table table-hover">
		<thead>
			<tr>
				<th>Task Title</th>
				<th>Task Desc</th>
                <th>Task Status</th>
                <th>Created </th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
<?php if(count($task)): foreach($task as $article): ?>	
		<tr>
			<td><?php echo anchor('admin/task/edit/' . $article->id, $article->task_title); ?></td>
			<td><?php echo $article->task_disc; ?></td>
            <td><?php echo $article->task_status; ?></td>
            <td><?php echo $article->created; ?></td>
			<td><?php echo btn_edit('admin/task/edit/' . $article->id); ?></td>
			<td><?php echo btn_delete('admin/task/delete/' . $article->id); ?></td>
		</tr>
<?php endforeach; ?>
<?php else: ?>
		<tr>
			<td colspan="3">We could not find any articles.</td>
		</tr>
<?php endif; ?>	
		</tbody>
	</table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>