<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">User List </h3> <h3 class="box-title" style=" float:right ; margin-right: 50% "> <a href="<?php echo base_url()."admin/user/add_user" ?>" class="btn btn-sm btn-success"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add User </a></h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
             
                <tbody>
                <tr>
                <th>Id</th>
                <th>Username</th>
                <th>Name</th>
                <th>Email</th>
                <th>Registerd Date</th>
                <th>Edit</th>
                <th>Delete</th>
                </tr>
                
                 <?php foreach($users as $user){?> <tr>
                  <td><?php  echo $user->id ;?></td>
                  <td><?php  echo $user->user_login ;?></td>
                  <td><?php echo $user->user_nicename ;?></td>
                  <td><?php  echo $user->user_email ; ?></td>
                  <td><?php echo $user->created  ; ?> </td>
                  <td><?php echo btn_edit('admin/user/edit_user/' . $user->id); ?></td>
                  <td><?php echo btn_delete('admin/user/delete_user/' . $user->id); ?></td>
                </tr>
                   <?php }?>  
                
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>