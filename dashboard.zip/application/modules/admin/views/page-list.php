<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Page List </h3> <h3 class="box-title" style=" float:right ; margin-right: 50% "> <a href="<?php echo base_url()."admin/page/edit" ?>" class="btn btn-sm btn-success"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add A Page </a></h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
             
                <tbody>
                <tr>
                <th>Title</th>
                <th>Parent</th>
                <th>Edit</th>
                <th>Delete</th>
                </tr>
                
                 <?php if(count($pages)): foreach($pages as $page): ?>	 <tr>
                  <td><?php echo anchor('admin/page/edit/' . $page->id, $page->title); ?></td>
			      <td><?php echo $page->parent_slug; ?></td>
                 <td><?php echo btn_edit('admin/page/edit/' . $page->id); ?></td>
			     <td><?php echo btn_delete('admin/page/delete/' . $page->id); ?></td>
                </tr>
                  <?php endforeach; ?>
                  <?php else: ?>
                  <tr>
			<td colspan="3">We could not find any pages.</td>
		 </tr>
         <?php endif; ?>	
                
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>