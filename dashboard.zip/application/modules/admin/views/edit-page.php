<div class=" col-md-offset-1 col-md-10 "><div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"> <?php echo empty($page->id) ? 'Add a new page' : 'Edit page ' . $page->title; ?></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
    <div class="text-center">    <?php echo validation_errors(); ?> </div>
<?php echo form_open(); ?>
              <div class="box-body form-horizontal">
               <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Parent</label>

                  <div class="col-sm-10">
                    <?php echo form_dropdown('parent_id', $pages_no_parents, $this->input->post('parent_id') ? $this->input->post('parent_id') : $page->parent_id); ?>
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Title</label>

                  <div class="col-sm-10">
                    <?php echo form_input('title', set_value('title', $page->title), 'class="form-control"'); ?>
                  </div>
                </div>
               
             
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Slug</label>

                  <div class="col-sm-10">
                   <?php echo form_input('slug', set_value('slug', $page->slug), 'class="form-control"'); ?>
                  </div>
                </div>
                
                   <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">Body</label>

                  <div class="col-sm-10">
                    <?php echo form_textarea('body', html_entity_decode(set_value('body', $page->body )),'id="editor1"', 'class="form-control"'); ?>
                  </div>
                </div>
                  
               
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
              <?php echo form_submit('submit', 'Save', 'class="btn btn-info pull-right"'); ?>
              
              </div>
              <!-- /.box-footer -->
     <?php echo form_close(); ?>
          </div>
		 