<?php
class Task_cat_m extends MY_Model
{
	protected $_table_name = 'categories';
	protected $_order_by = 'pubdate desc, id desc';
	protected $_timestamps = FALSE;
	public $rules = array(
		'pubdate' => array(
			'field' => 'pubdate', 
			'label' => 'Publication date', 
			'rules' => 'trim|required|exact_length[10]'
		), 
		'title' => array(
			'field' => 'title', 
			'label' => 'Title', 
			'rules' => 'trim|required|max_length[100]'
		), 
		
		'disc' => array(
			'field' => 'disc', 
			'label' => 'Disc', 
			'rules' => 'trim|required'
		)
	);
	
	public function get_new ()
	{
		$cat = new stdClass();
		$cat->title = '';
		$cat->disc = '';
		$cat->pubdate = date('Y-m-d');
		return $cat;
	}

}