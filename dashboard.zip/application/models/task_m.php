<?php
class Task_m extends MY_Model
{
	protected $_table_name = 'task_details';
	protected $_order_by = 'created desc, id desc';
	protected $_timestamps = TRUE;
	public $rules = array(
		
		'task_title' => array(
			'field' => 'task_title', 
			'label' => 'Task Title', 
			'rules' => 'trim|required|max_length[100]'
		), 
		'task_disc' => array(
			'field' => 'task_disc', 
			'label' => 'task disc', 
			'rules' => 'trim|required|max_length[100]|url_title'
		) 
		
	);

	public function get_new ()
	{
		$article = new stdClass();
		$article->task_title = '';
		$article->task_disc = '';
		return $article;
	}
	
}