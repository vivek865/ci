<?php
class User_M extends MY_Model
{
	
	protected $_table_name = 'users';
	protected $_order_by = 'user_nicename';
	protected $_primary_key = 'id';
	protected $_primary_filter = 'intval';
	public $rules_admin = array(
		'user_nicename' => array(
			'field' => 'user_nicename', 
			'label' => 'Name', 
			'rules' => 'trim|required'
		), 
		'user_login' => array(
			'field' => 'user_login', 
			'label' => 'Username', 
			'rules' => 'trim|required'
		), 
		'user_email' => array(
			'field' => 'user_email', 
			'label' => 'Email', 
			'rules' => 'trim|required|valid_email|callback__unique_email'
		), 
		'user_pass' => array(
			'field' => 'user_pass', 
			'label' => 'Password', 
			'rules' => 'trim|matches[password_confirm]|required'
		),
		'password_confirm' => array(
			'field' => 'password_confirm', 
			'label' => 'Confirm password', 
			'rules' => 'trim|matches[user_pass]'
		),
	);
	public $rules1 = array(
						  
		 'name' => array(
			'field' => 'name', 
			'label' => 'Name', 
			'rules' => 'trim|required'
		), 
		'email' => array(
			'field' => 'email', 
			'label' => 'Email', 
			'rules' => 'trim|required|valid_email'
		), 
		'password' => array(
			'field' => 'password', 
			'label' => 'Password', 
			'rules' => 'trim|required'
		),
		'cnf_password' => array(
			'field' => 'cnf_password', 
			'label' => 'Conform Password', 
			'rules' => 'trim|required|matches[password]'
		)
		
	);
	public $rules = array(
		'email' => array(
			'field' => 'email', 
			'label' => 'Email', 
			'rules' => 'trim|required|valid_email'
		), 
		'password' => array(
			'field' => 'password', 
			'label' => 'Password', 
			'rules' => 'trim|required'
		)
		
	);

	function __construct ()
	{
		parent::__construct();
	}

	public function login ()
	{
		$user = $this->get_by(array(
			'user_email' => $this->input->post('email'),
			'user_pass' => $this->hash($this->input->post('password')),
		), TRUE);
		
		if (count($user)) {
			// Log in user
			$data = array(
				'name' => $user->user_nicename,
				'email' => $user->user_email,
				'id' => $user->id,
				'loggedin' => TRUE,
			);
			$this->session->set_userdata($data);
		}
	}
public function register ()
	{
		$user = $this->save(array(
			'id' => '',
			'user_login' => '',
			'user_pass' => $this->hash($this->input->post('password')),
			'user_nicename' =>$this->input->post('name'),
			'user_email' => $this->input->post('email'),
			'activation_key' => '',
			'created' => '' ,
			'modified' => '' ,
			'status' => '' ,
		));
		
		
	}
	
	public function user_list()
	{
		$user = $this->get() ;
		return $user ;
	}
	public function delete_user()
	{
		$id = $this->uri->segment(4);
		if($_SESSION['id']== $id )
		{
		return FALSE ;
		}
		$this->delete($id) ;
		
	}


	public function logout ()
	{
		$this->session->sess_destroy();
	
	}

	public function loggedin ()
	{
		return (bool) $this->session->userdata('loggedin');
	}

	public function hash ($string)
	{
		return hash('sha512', $string . config_item('encryption_key'));
	}
	public function get_new(){
	$user = new stdClass();
		$user->user_nicename = '';
		$user->user_login ='';
		$user->user_email = '';
		$user->user_pass = '';
		
		return $user;
	}

}