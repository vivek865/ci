<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-10-29 13:57:43 --> 404 Page Not Found --> http://cms:8888/dummy
ERROR - 2012-10-29 16:23:48 --> Severity: Warning  --> The magic method __call() must have public visibility and cannot be static /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 22
ERROR - 2012-10-29 16:25:56 --> 404 Page Not Found --> http://cms:8888/dummy
ERROR - 2012-10-29 16:27:53 --> Severity: 4096  --> Object of class Page could not be converted to string /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 17
ERROR - 2012-10-29 16:27:53 --> Severity: Notice  --> Object of class Page to string conversion /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 17
ERROR - 2012-10-29 16:27:53 --> Severity: Notice  --> Undefined property: Page::$Object /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 17
ERROR - 2012-10-29 16:27:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 17
ERROR - 2012-10-29 16:36:11 --> 404 Page Not Found --> http://cms:8888/dummy
ERROR - 2012-10-29 16:47:52 --> 404 Page Not Found --> http://cms:8888/page/foo
ERROR - 2012-10-29 17:31:13 --> 404 Page Not Found --> http://cms:8888/admin
ERROR - 2012-10-29 17:31:19 --> 404 Page Not Found --> http://cms:8888/admin/user/login
ERROR - 2012-10-29 17:31:24 --> 404 Page Not Found --> http://cms:8888/admin/user/login
ERROR - 2012-10-29 17:31:53 --> 404 Page Not Found --> admin/$1
ERROR - 2012-10-29 17:31:56 --> 404 Page Not Found --> admin/$1
ERROR - 2012-10-29 17:32:28 --> 404 Page Not Found --> admin/$1
ERROR - 2012-10-29 17:59:22 --> Severity: Notice  --> Undefined variable: e /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 17
ERROR - 2012-10-29 18:16:39 --> Severity: Notice  --> Undefined variable: subview /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/_main_layout.php 21
ERROR - 2012-10-29 18:16:41 --> Severity: Notice  --> Undefined variable: subview /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/_main_layout.php 21
ERROR - 2012-10-29 18:16:42 --> Severity: Notice  --> Undefined variable: subview /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/_main_layout.php 21
ERROR - 2012-10-29 18:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:68) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-29 18:27:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:68) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-29 18:27:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:68) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-29 18:55:41 --> Severity: Notice  --> Undefined variable: limit /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 23
ERROR - 2012-10-29 19:00:58 --> Severity: Warning  --> Missing argument 2 for limit_to_numwords(), called in /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php on line 19 and defined /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 23
ERROR - 2012-10-29 19:00:58 --> Severity: Notice  --> Undefined variable: numwords /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 24
ERROR - 2012-10-29 19:00:58 --> Severity: Notice  --> Undefined variable: numwords /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 25
ERROR - 2012-10-29 19:01:32 --> Severity: Warning  --> Missing argument 2 for limit_to_numwords(), called in /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php on line 19 and defined /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 23
ERROR - 2012-10-29 19:01:32 --> Severity: Notice  --> Undefined variable: numwords /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 24
ERROR - 2012-10-29 19:01:32 --> Severity: Notice  --> Undefined variable: numwords /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 25
ERROR - 2012-10-29 19:01:36 --> Severity: Warning  --> Missing argument 2 for limit_to_numwords(), called in /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php on line 19 and defined /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 23
ERROR - 2012-10-29 19:01:36 --> Severity: Notice  --> Undefined variable: numwords /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 24
ERROR - 2012-10-29 19:01:36 --> Severity: Notice  --> Undefined variable: numwords /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 25
ERROR - 2012-10-29 22:34:39 --> Severity: Notice  --> Undefined variable: url /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 22
ERROR - 2012-10-29 23:40:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `pubdate` <= '2012-10-29'' at line 2
ERROR - 2012-10-29 23:41:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `pubdate` = '2012-10-29'' at line 2
ERROR - 2012-10-29 23:41:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `pubdate` <= '2012-10-29'' at line 2
ERROR - 2012-10-29 23:47:48 --> 404 Page Not Found --> http://cms:8888/4
