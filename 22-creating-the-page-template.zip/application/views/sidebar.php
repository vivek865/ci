<?php echo anchor($news_archive_link, '+ News archive'); ?>
<?php echo article_links($recent_news); ?>