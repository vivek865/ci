<?php
class Order_m extends MY_Model
{
	protected $_table_name = 'orders';
	protected $_order_by = 'id desc';
	protected $_timestamps = TRUE;
	public $rules1 = array(
	
	'date' => array(
			'field' => 'date', 
			'label' => 'Discription', 
			'rules' => 'trim|required'
		), 
		'cats' => array(
			'field' => 'cats', 
			'label' => 'Categories', 
			'rules' => 'trim|required'
		), 
	
	) ;
		public $rules = array(
		'date' => array(
			'field' => 'date', 
			'label' => 'Discription', 
			'rules' => 'trim|required'
		), 
		'cats' => array(
			'field' => 'cats', 
			'label' => 'Categories', 
			'rules' => 'trim|required'
		), 
	);
	
	}