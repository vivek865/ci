<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
           <h3 class="box-title">Appointment  List </h3> <h3 class="box-title" style=" float:right ; margin-right: 50% ">   <!-- <?php echo anchor('business_owner/appoitment/edit', '<i class="fa fa-plus-circle"></i> Add an Appointment'); ?>--></h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            <table class="table table-hover">
		<thead>
			<tr>
                <th>Order Id</th>
                <th>Order By </th>
                <th>Order On </th>
				        <th>Delivery Date</th>
                <th>Payment Status</th>
                <th>Payment Mode</th>
                <th>Order Status</th>
                <th>Order Deatils</th>
                <th>File Download Link </th>
                <th>Deliver Now</th>
          			<th>Edit</th>
          			<th>Delete</th>
			</tr>
		</thead>
		<tbody>
<tr>
  <td>1</td>
    <td>xyz@gmail.com</td>
      <td>28/02/2017</td>
        <td>30/02/2017</td>
          <td>Paid</td>
            <td>Banktransfer</td>
              <td>Processing</td>
                <td><a href="#" ><span class="label label-default"> <i class="fa fa-eye " aria-hidden="true"> </i> Order Details </span></a></td>
                  <td>Download link</td>
                    <td><a href="<?php echo site_url('business_owner/order/deliver') ; ?>" ><span class="label label-success"> <i class="fa  fa-cloud-upload " aria-hidden="true"> </i> Deliver Now </span></a></td>
                      <td><a href="#"><span class="label label-primary"><i class="fa fa-pencil-square-o " aria-hidden="true"> Edit </i></span></a></td>
                        <td><a href="#"><span class="label label-danger"> <i class="fa fa-minus-circle " aria-hidden="true"> </i> Delete </span></a></td>
</tr>
		</tbody>
	</table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>