<?php   
class Order extends Business_Controller
{
		public function __construct ()
	{
		parent::__construct();
		$this->load->model('order_m');
	}
public function index()
{

	  $this->data['main_content'] = 'list_order';
	  $this->load->view('business-owner-theme/dashboard',$this->data );

}
public function deliver()
{
$this->data['main_content'] = 'deliver_order';
$this->load->view('business-owner-theme/dashboard',$this->data );	
}
public function do_upload()
        {
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = '*';
                $config['encrypt_name'] = TRUE ;
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile'))
                {
                        $this->data['error'] = array('error' => $this->upload->display_errors());

			$this->data['main_content'] = 'deliver_order';
			$this->load->view('business-owner-theme/dashboard',$this->data );	
                        
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                        	echo $data['upload_data']['file_name'] ;
                   
                        $this->load->view('upload_success', $data);
                }
        }


}
