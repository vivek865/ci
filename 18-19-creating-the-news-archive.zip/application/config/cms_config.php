<?php
$config['site_name'] = 'Death Star Daily';